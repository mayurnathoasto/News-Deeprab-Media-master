<?php

use App\Http\Controllers\Api\BookmarkLikeApiController;
use App\Http\Controllers\Api\CommentApiController;
use App\Http\Controllers\Api\ContentApiController;
use App\Http\Controllers\Api\MediaApiController;
use App\Http\Controllers\Api\NewsApiController;
use App\Http\Controllers\Api\RssApiController;
use App\Http\Controllers\Api\SettingsApiController;
use App\Http\Controllers\Api\UserApiController;
use App\Http\Controllers\Api\SurveyApiController;
use App\Http\Controllers\Api\WebStoryApiController;
use App\Http\Controllers\Api\LanguageApiController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// ---- Settings, languages, categories, locations, pages, notifications ----
Route::post('get_settings',                [SettingsApiController::class, 'getSettings']);
Route::post('get_pages',                   [SettingsApiController::class, 'getPages']);
Route::post('get_policy_pages',            [SettingsApiController::class, 'getPolicyPages']);
Route::post('get_location',                [SettingsApiController::class, 'getLocation']);
Route::post('get_category',                [SettingsApiController::class, 'getCategory']);
Route::post('get_subcategory_by_category', [SettingsApiController::class, 'getSubcategoryByCategory']);
Route::post('get_tag',                     [SettingsApiController::class, 'getTag']);
Route::post('get_notification',            [SettingsApiController::class, 'getNotification']);
Route::post('get_web_seo_pages',           [SettingsApiController::class, 'getWebSeoPages']);
Route::post('get_ad_space_news_details',   [SettingsApiController::class, 'getAdSpaceNewsDetails']);
Route::post('get_ad_space_home_sidebar',   [SettingsApiController::class, 'getAdSpaceHomeSidebar']);
Route::post('get_web_stories',             [WebStoryApiController::class, 'getWebStories']);
Route::post('track_web_story_event',       [WebStoryApiController::class, 'trackWebStoryEvent']);
Route::post('get_question_result',          [SurveyApiController::class, 'getQuestionResult']);
Route::post('set_question_result',          [SurveyApiController::class, 'setQuestionResult']);
Route::post('get_question',                 [SurveyApiController::class, 'getQuestion']);

// ---- Languages ----
Route::post('get_languages_list',          [LanguageApiController::class, 'getLanguagesList']);
Route::post('get_language_json_data',      [LanguageApiController::class, 'getLanguageJsonData']);

// ---- Media ----
Route::post('get_live_streaming', [MediaApiController::class, 'getLiveStreaming']);

// ---- RSS ----
Route::post('get_rss_feed',       [RssApiController::class, 'getRssFeed']);

// ---- Auth-optional routes ----
Route::group(['middleware' => ['auth.optional']], function () {
    Route::post('set_news_view',         [ContentApiController::class, 'setNewsView']);
    Route::post('set_breaking_news_view',[ContentApiController::class, 'setBreakingNewsView']);
    Route::post('get_featured_sections', [ContentApiController::class, 'getFeaturedSections']);
    Route::post('get_breaking_news',     [ContentApiController::class, 'getBreakingNews']);

    Route::post('get_news',   [NewsApiController::class, 'getNews']);
    Route::post('get_videos', [MediaApiController::class, 'getVideos']);

    Route::post('get_comment_by_news', [CommentApiController::class, 'getCommentByNews']);

    // Author news (public)
    Route::post('get_authors_news', [NewsApiController::class, 'getAuthorsNews']);
});

// ---- Public user/device endpoints ----
Route::post('user_signup',    [UserApiController::class, 'userSignup']);
Route::post('register_token', [UserApiController::class, 'registerToken']);

Route::post('check_slug_availability', [NewsApiController::class, 'checkSlugAvailability']);

Route::post('get_short_news', [NewsApiController::class, 'getShortNews']);

// ---- Authenticated routes ----
Route::group(['middleware' => ['auth:sanctum', 'sanitize']], function () {

    // News
    Route::post('delete_news_images', [NewsApiController::class, 'deleteNewsImages']);
    Route::post('delete_news',        [NewsApiController::class, 'deleteNews']);
    Route::post('set_news',           [NewsApiController::class, 'setNews']);
    Route::post('get_user_drafted_news', [NewsApiController::class, 'getUserDraftedNews']);
    Route::post('create_tag',         [NewsApiController::class, 'createTag']);

    // Bookmarks & Likes
    Route::post('get_bookmark',    [BookmarkLikeApiController::class, 'getBookmark']);
    Route::post('set_bookmark',    [BookmarkLikeApiController::class, 'setBookmark']);
    Route::post('get_like',        [BookmarkLikeApiController::class, 'getLike']);
    Route::post('set_like_dislike',[BookmarkLikeApiController::class, 'setLikeDislike']);

    // Comments
    Route::post('set_flag',                [CommentApiController::class, 'setFlag']);
    Route::post('set_comment_like_dislike',[CommentApiController::class, 'setCommentLikeDislike']);
    Route::post('delete_comment',          [CommentApiController::class, 'deleteComment']);
    Route::post('set_comment',             [CommentApiController::class, 'setComment']);

    // User
    Route::post('delete_user_notification', [UserApiController::class, 'deleteUserNotification']);
    Route::post('get_user_notification',    [UserApiController::class, 'getUserNotification']);
    Route::post('set_user_category',        [UserApiController::class, 'setUserCategory']);
    Route::post('delete_user',              [UserApiController::class, 'deleteUser']);
    Route::post('update_profile',           [UserApiController::class, 'updateProfile']);
    Route::post('get_user_by_id',           [UserApiController::class, 'getUserById']);
    Route::post('become_author',            [UserApiController::class, 'becomeAuthor']);
    Route::post('update_author_profile',    [UserApiController::class, 'updateAuthorProfile']);
});

// ---- E-News ----
Route::post('get_e_news', [ContentApiController::class, 'getENews']);

// ---- Feed items from RSS source ----
Route::match(['get', 'post'], 'get_feed_items', [ContentApiController::class, 'getFeedItems']);

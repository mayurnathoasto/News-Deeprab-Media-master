<?php
return array('current_version' => '3.2.4','update_version' => '3.2.5');